{ pkgs }: {
    deps = [
        pkgs.gtkwave
        pkgs.ghdl-llvm
        pkgs.cowsay
    ];
}