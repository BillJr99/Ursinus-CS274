library ieee;
use ieee.std_logic_1164.all;

entity and2 is
    port (
        a  : in  std_logic;
        b  : in  std_logic;
        z : out std_logic);
end and2;

architecture behavioral of and2 is
begin
    -- This is a comment: set z to a and b with a 2ns delay
    z <= a and b after 2 ns;
end;