library ieee;
use ieee.std_logic_1164.all;

entity and2_tb is
end and2_tb;

architecture behavior of and2_tb is
    component and2 is
    port (
        a  : in  std_logic;
        b  : in  std_logic;
        z : out std_logic);    
    end component;
    
    signal input  : std_logic_vector(1 downto 0);
    signal output : std_logic;
begin
    test1: and2 port map (
        a => input(0),
        b => input(1),
        z => output
    );

    tb_proc: process
    begin
        input <= "00"; wait for 30 ns; assert output = '0' report "0&0 failed";
        input <= "01"; wait for 30 ns; assert output = '0' report "0&1 failed";
        input <= "10"; wait for 30 ns; assert output = '0' report "1&0 failed";
        input <= "11"; wait for 30 ns; assert output = '1' report "1&1 failed";
        report "Testbench finished";
        wait;
    end process;
end;