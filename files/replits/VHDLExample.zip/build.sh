# may need to run ghdl and gtkwave independently from a terminal to get them to install to replit.nix the first time; press Y or enter when prompted to install these packages.

ghdl -a and2.vhd
ghdl -a and2_tb.vhd
ghdl -e and2_tb
ghdl -r and2_tb --vcd=waveform.vcd
gtkwave waveform.vcd