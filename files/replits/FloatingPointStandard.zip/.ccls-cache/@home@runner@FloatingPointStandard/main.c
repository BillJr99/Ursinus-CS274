#include <stdio.h>

// https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
// Assumes little endian
void printBits(size_t const size, void const *const ptr) {
  unsigned char *b = (unsigned char *)ptr;
  unsigned char byte;
  int i, j;

  for (i = size - 1; i >= 0; i--) {
    for (j = 7; j >= 0; j--) {
      byte = (b[i] >> j) & 1;
      printf("%u", byte);
    }
  }
  puts("");
}

struct f754 {
  int mantissa : 23; // least significant bits
  int exp : 8;
  int signbit : 1; // most significant bit
};

union float754 {
  float fval;
  struct f754 f754val;
};

int main(void) {
  union float754 f;
  f.fval = 0.5;

  printf("float value: %f\n", f.fval);

  printf("Sign: %d\n", f.f754val.signbit);

  printf("Exponent: ");
  int exp = f.f754val.exp;
  printBits(1, &exp);

  printf("Mantissa: ");
  int mantissa = f.f754val.mantissa;
  printBits(3, &mantissa);

  return 0;
}