def fwriteln(f, str="", tabs=0):
  str = ("    " * tabs) + str + "\r\n"
  f.write(str)
  f.flush()


def countpins(port, ports):
  pins = 1  # assume 1 pin for single ports, and add the starting index if there is a downto 0 (since pin 0 counts as 1 either way)
  if "downto 0)" in ports[port]:
    tokens = ports[port].split(" ")  # (x downto 0), returns int(x)
    lasttok = None
    for token in tokens:
      if not (lasttok is None):
        if token == "downto":
          pins += int(lasttok.split("(")[1])
          break
      lasttok = token

  return pins


def createtb(f, component, ports, truth):
  fwriteln(f, "library ieee;")
  fwriteln(f, "use ieee.std_logic_1164.all;")
  fwriteln(f)
  fwriteln(f, "entity {}_tb is".format(component))
  fwriteln(f, "end {}_tb".format(component))
  fwriteln(f)
  fwriteln(f, "architecture behavior of {}_tb is".format(component))
  fwriteln(f, "component {} is".format(component), tabs=1)
  fwriteln(f, "port (", tabs=1)

  i = 0
  inputs = 0
  outputs = 0
  for port in ports:
    portstr = "{}: {};".format(port, ports[port])
    if i == len(ports) - 1:
      portstr = portstr[:-1]  # remove last semicolon
    fwriteln(f, portstr, tabs=2)
    i += 1

    pins = countpins(port, ports)

    if ": in " in portstr:
      inputs += pins
    if ": out " in portstr:
      outputs += pins

  fwriteln(f, "end component;", tabs=1)
  fwriteln(f)

  inputsignalstr = "signal input : "
  if inputs > 1:
    inputsignalstr += "std_logic_vector({} downto 0);".format(str(inputs - 1))
  else:
    inputsignalstr += " std_logic;"

  fwriteln(f, inputsignalstr, tabs=1)

  outputsignalstr = "signal output : "
  if outputs > 1:
    outputsignalstr += "std_logic_vector({} downto 0);".format(str(outputs -
                                                                   1))
  else:
    outputsignalstr += " std_logic;"

  fwriteln(f, outputsignalstr, tabs=1)

  fwriteln(f, "begin")

  fwriteln(f, "test1: {} port map (".format(component), tabs=1)

  inputcount = 0
  outputcount = 0
  portstr = ""
  for port in ports:
    pins = countpins(port, ports)
    if pins > 1:
      for j in range(pins):
        portstr += "{}({})".format(port, j)

        portstr += " => "
        if ports[port].startswith("in "):
          if inputs > 1:
            portstr += "input({}),".format(inputcount)
          else:
            portstr += "input,"
          inputcount += 1
        if ports[port].startswith("out "):
          if outputs > 1:
            portstr += "output({}),".format(outputcount)
          else:
            portstr += "output,"
          outputcount += 1
    else:
      portstr += "{}".format(port)

      portstr += " => "
      if ports[port].startswith("in "):
        if inputs > 1:
          portstr += "input({}),".format(inputcount)
        else:
          portstr += "input,"
        inputcount += 1
      if ports[port].startswith("out "):
        if outputs > 1:
          portstr += "output({}),".format(outputcount)
        else:
          portstr += "output,"
        outputcount += 1

  portlines = portstr.split(",")
  for i in range(len(portlines) - 1, 0, -1):
    if len(portlines[i].strip()) < 1:
      portlines.remove(portlines[i])

  for i in range(len(portlines)):
    portline = "{},".format(portlines[i])
    if i == len(portlines) - 1:
      portline = portline[:-1]  # remove last comma
    fwriteln(f, portline, tabs=2)

  fwriteln(f, ");", tabs=1)
  fwriteln(f)

  fwriteln(f, "tb_proc: process", tabs=1)
  fwriteln(f, "begin", tabs=1)

  if inputs > 1:
    inputquote = "\""
  else:
    inputquote = "\'"

  if outputs > 1:
    outputquote = "\""
  else:
    outputquote = "\'"

  for truthitem in truth:
    fwriteln(
      f,
      "input <= {}{}{}; wait for 30 ns; assert output = {}{}{} report \"{} failed\""
      .format(inputquote, truthitem, inputquote, outputquote, truth[truthitem],
              outputquote, truthitem),
      tabs=2)

  fwriteln(f, "report \"Testbench Finished\";", tabs=2)
  fwriteln(f, "wait;", tabs=2)

  fwriteln(f, "end process", tabs=1)
  fwriteln(f, "end;")


def writetb(component, ports, truth):
  f = open("{}_tb.vhd".format(component), 'w')

  createtb(f, component, ports, truth)

  f.close()


def getconfig(conffile="config.txt"):
  cf = open(conffile)

  lines = cf.readlines()

  component = lines[0].strip()

  ports = {}
  truth = {}

  state = 0
  for line in lines[2:]:
    if len(line.strip()) < 1:
      state += 1
      continue

    if state == 0:
      data = line.split(":")
      key = data[0].strip()
      value = data[1].strip()
      ports[key] = value
    elif state == 1:
      data = line.split(":")
      key = data[0].strip()
      value = data[1].strip()
      truth[key] = value

  cf.close()

  return component, ports, truth


component, ports, truth = getconfig()

writetb(component, ports, truth)
