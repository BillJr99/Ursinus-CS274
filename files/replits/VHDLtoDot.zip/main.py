import re
import sys

def parse_entity_ports(entity_declaration):
    port_pattern = r"(\w+)\s*:\s*(in|out)\s+(\w+)"
    ports = re.findall(port_pattern, entity_declaration, re.IGNORECASE)
    return [(port[0], port[1], port[2]) for port in ports]

def parse_components(component_declarations):
    components = {}
    for component_declaration in component_declarations:
        name = component_declaration[0]
        ports = parse_entity_ports(component_declaration[1])
        components[name] = ports
    return components

def parse_port_maps(instantiations):
    port_maps = {}
    for instantiation in instantiations:
        instantiation = instantiation.strip()

        instance_name = re.search(r"(\w+)\s*:\s*(\w+)", instantiation, re.IGNORECASE).group(2)
        port_map_text = re.search(r"port\s*map\s*\((.*?)\)", instantiation, re.IGNORECASE | re.DOTALL).group(1)
        port_map = re.findall(r"(\w+)\s*=>\s*(\w+)", port_map_text, re.IGNORECASE)
        port_maps[instance_name] = port_map
    return port_maps

def generate_dotty(entity_ports, components, port_maps):
    dotty = "digraph G {\n"
    for port in entity_ports:
        dotty += f'"{port[0]}" [label="{port[0]}\\n{port[1]} {port[2]}"];\n'
    for instance_name, port_map in port_maps.items():
        for src, dst in port_map:
            dotty += f'"{instance_name}" -> "{dst}" [label="{src}"];\n'
    dotty += "}\n"
    return dotty

def main(vhdl_file):
    with open(vhdl_file, "r") as f:
        text = f.read()
    
    entity_declaration = re.search(r"entity\s+\w+\s+is(.*?)end\s+(.*?);", text, re.IGNORECASE | re.DOTALL).group(1)
    entity_ports = parse_entity_ports(entity_declaration)
    
    component_declarations = re.findall(r"component\s+(.*?)\s+(.*?)end\s+component", text, re.IGNORECASE | re.DOTALL)
    components = parse_components(component_declarations)
   
    instantiations = re.findall(r"(\s*\w+\s*:\s*\w+\s+port\s+map\s*\(.*?\);)", text, re.IGNORECASE | re.DOTALL)
    port_maps = parse_port_maps(instantiations)
    
    dotty = generate_dotty(entity_ports, components, port_maps)
    
    with open("output.dot", "w") as f:
        f.write(dotty)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python main.py <VHDL_FILE>")
        sys.exit(1)
    main(sys.argv[1])