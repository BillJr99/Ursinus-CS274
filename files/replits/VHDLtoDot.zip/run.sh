python3 main.py adder.vhd
dot -Tpng output.dot -o output.png